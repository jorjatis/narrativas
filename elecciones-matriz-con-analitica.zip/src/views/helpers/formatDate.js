// Formatea fecha a formato DD/MM/YYYY
// Uso:
// {{formatDate fecha}}

module.exports = function(dateString) {
  if (!dateString) return '';

  const date = new Date(dateString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();

  return `${day}/${month}/${year}`;
};